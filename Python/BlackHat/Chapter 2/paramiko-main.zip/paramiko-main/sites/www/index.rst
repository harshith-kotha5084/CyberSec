.. include:: ../../README.rst

.. toctree::
    :hidden:

    changelog
    FAQs <faq>
    installing
    installing-1.x
    contributing
    contact


