# SVNDigger
Wordlists for Wfuzz or Dirbuster

These wordlists are from [netsparker.com](https://www.netsparker.com/blog/web-security/svn-digger-better-lists-for-forced-browsing/). This repository is simply a copy for archival purposes.
